module DBClientApp {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.desktop;
    requires java.sql;
    requires javafx.graphics;

    opens termProject;
}